import React from "react";

class Form extends React.Component {
    constructor() {
        super();

        this.state = {
            inputLetter: ''
            // countShow: 2,
            // countShowPopUp: false,
            // myArticle: articleArr
        };

        this.myAdd = this.myAdd.bind(this);
        this.LetterChange = this.LetterChange.bind(this);
        // this.addArticle = this.addArticle.bind(this);
    }

    myAdd() {
        fetch(`https://api.themoviedb.org/3/search/multi?api_key=39a3fe1b6db3dfb1cf6cc4cbc1f0db5e&query=${this.state.inputLetter}`)
            .then(function(response) {
                return response.json().then(function (response) {
                    console.log(response);
                });
            })
            .catch( alert );
        // this.setState({
        //
        // });
    }

    LetterChange (e) {
        this.setState({
            inputLetter : e.target.value
        });
    }
    render() {
        // const {title, author, text} = this.props;
        return (
            <div>
                <form action="">
                    <label className="main-input">
                        <input onKeyPress={this.myAdd} onChange={this.LetterChange} type="text"/>
                    </label>

                </form>
            </div>
        )
    }
};

export default Form;